//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "G:\PortableSoft\JBY\MC_Deobf3000\1.12-MCP-Mappings"!

package me.rebirthclient.api.util;

import net.minecraft.client.Minecraft;

public interface Wrapper {
   Minecraft mc = Minecraft.getMinecraft();
}
