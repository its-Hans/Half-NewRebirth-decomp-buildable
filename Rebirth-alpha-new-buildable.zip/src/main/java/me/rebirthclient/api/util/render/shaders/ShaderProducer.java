package me.rebirthclient.api.util.render.shaders;

@FunctionalInterface
public interface ShaderProducer {
   FramebufferShader INSTANCE();
}
