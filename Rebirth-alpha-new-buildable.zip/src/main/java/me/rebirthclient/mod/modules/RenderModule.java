package me.rebirthclient.mod.modules;

import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.Wrapper;

public class RenderModule implements Wrapper {
   public void onRender3D(Render3DEvent event) {
   }
}
